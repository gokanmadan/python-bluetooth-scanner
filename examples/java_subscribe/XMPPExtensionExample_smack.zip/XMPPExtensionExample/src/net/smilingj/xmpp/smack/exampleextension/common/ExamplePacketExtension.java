package net.smilingj.xmpp.smack.exampleextension.common;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class ExamplePacketExtension implements PacketExtension {
	
	private String exampleAttribut;
	
	public static String namespace = "http://smilingj.net/xmpp";
	public static String elementname = "exampleextension";
	
	public ExamplePacketExtension() {
	}
	
	public void setExampleAttribut(String value) {
		exampleAttribut = value;
	}
	
	public String getExampleAttribut() {
		return exampleAttribut;
	}

	public String getElementName() {
		return ExamplePacketExtension.elementname;
	}

	public String getNamespace() {
		return ExamplePacketExtension.namespace;
	}

	public String toXML() {
		StringBuffer buf = new StringBuffer();
		
		buf.append("<").append(getElementName()).append(" xmlns=\"").append(getNamespace()).append("\">");
		if(exampleAttribut != null) buf.append("<content exampleattribut=\"").append(exampleAttribut).append("\"/>");
		buf.append("</").append(getElementName()).append(">");
		
		return buf.toString();
	}
	
	public static class Provider implements PacketExtensionProvider{

		public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
			ExamplePacketExtension extension = new ExamplePacketExtension();
			boolean done = false;
			while(!done) {
				int eventType = parser.next();
				if(eventType == XmlPullParser.START_TAG) {
					if(parser.getName().equals("content")) {
						extension.setExampleAttribut(parser.getAttributeValue("", "exampleattribut"));
						done = true;
					}
				}
			}
			return extension;
		}

	}

}
