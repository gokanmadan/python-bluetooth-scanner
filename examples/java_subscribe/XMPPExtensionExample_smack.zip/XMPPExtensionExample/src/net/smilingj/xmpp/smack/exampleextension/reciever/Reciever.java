package net.smilingj.xmpp.smack.exampleextension.reciever;

import net.smilingj.xmpp.smack.exampleextension.common.ExamplePacketExtension;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.filter.PacketExtensionFilter;
import org.jivesoftware.smack.packet.Packet;

public class Reciever {

	/**
	 * @param args
	 */
	public static void main(String[] args) {		
		try {
			XMPPConnection.DEBUG_ENABLED = true;
			
			XMPPConnection connection = new XMPPConnection("jgrimm19");
			connection.connect();
			
			connection.addPacketListener(new PacketListener() {

				public void processPacket(Packet p) {
					ExamplePacketExtension e = (ExamplePacketExtension) p.getExtension(ExamplePacketExtension.namespace);
					System.out.println("Extension content: ("+e.getExampleAttribut()+")");
				}}, new PacketExtensionFilter(ExamplePacketExtension.namespace));
			
			connection.login("reciever", "RECIEVER");			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
